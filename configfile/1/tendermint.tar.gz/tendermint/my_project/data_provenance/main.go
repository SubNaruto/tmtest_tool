package main

import (
	"log"

	"github.com/tendermint/tendermint/my_project/data_provenance/web/router"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/util"
)

func init() {
	// 建立与redis server的连接
	err := util.InitRedis()
	if err != nil {
		log.Fatal(err)
	}

	// 初始化tendermint client list
	err = util.InitCliList()
	if err != nil {
		log.Fatal(err)
	}
}

func main() {
	engine := router.GenRouter()

	// 以9090端口开启web服务
	if err := engine.Run(":9090"); err != nil {
		log.Fatal(err)
	}
}
