package dao

import (
	"context"
	"fmt"
	"github.com/gogo/protobuf/proto"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/util"
	util2 "github.com/tendermint/tendermint/my_project/data_provenance/web/util/submit_tx/util"
	"github.com/tendermint/tendermint/proto/tendermint/types"
)

func DataProvenance(dataType int32, vectorCode string) (*types.ProvDataList, error) {
	cli := util.NewTendermintCli()

	res, err := cli.ProvQuery(context.TODO(), dataType, vectorCode)
	if err != nil {
		return nil, err
	}

	return res.ProvDataList, nil
}

func KnnOperation(tx *types.Tx) ([]byte, error) {
	cli := util.NewTendermintCli()

	pbTx, err := proto.Marshal(tx)
	if err != nil {
		return nil, err
	}

	if tx.TxBody.OpType != types.OperationType_SELECT {
		resp, err := cli.BroadcastTxAsync(context.TODO(), pbTx)
		if err != nil {
			return nil, err
		}
		return resp.Data, nil
	} else {
		response, err := cli.BroadcastTxCommit(context.TODO(), pbTx)
		if err != nil {
			return nil, err
		}
		return response.DeliverTx.Data, nil
	}
}

func Submit() error {
	cli := util.NewTendermintCli()

	// 插入数据
	for vectorCode := 0; vectorCode < 100; vectorCode++ { // vectorCode从0到99, 总计100个
		fmt.Printf("send insert tx %d\n", vectorCode)
		v := util2.RandomPoint()
		tx1 := util2.GenerateInsertTx(util.Redis, vectorCode+1, v, types.DataType_VIDEO, "001")  // 插入视频类型的数据(100个)
		tx2 := util2.GenerateInsertTx(util.Redis, vectorCode+1, v, types.DataType_SERIES, "001") // 插入序列类型的数据(100个)
		tx3 := util2.GenerateInsertTx(util.Redis, vectorCode+1, v, types.DataType_TEXT, "001")   // 插入文本类型的数据(100个)

		util2.SendTx(cli, tx1)
		util2.SendTx(cli, tx2)
		util2.SendTx(cli, tx3)
	}

	// 更新数据
	for i := 0; i < 3; i++ { // 更新3次
		fmt.Printf("send update tx on vector %d\n", 1)
		v := util2.RandomPoint()

		tx1 := util2.GenerateUpdateTx(util.Redis, 10, v, types.DataType_VIDEO, "001") // vectorCode=10 且 类型为视频 的数据
		util2.SendTx(cli, tx1)

		tx2 := util2.GenerateUpdateTx(util.Redis, 10, v, types.DataType_SERIES, "001") // vectorCode=10 且 类型为序列 的数据
		util2.SendTx(cli, tx2)

		tx3 := util2.GenerateUpdateTx(util.Redis, 10, v, types.DataType_TEXT, "001") // vectorCode=10 且 类型为文本 的数据
		util2.SendTx(cli, tx3)
	}
	return nil
}
