package impl

import (
	"github.com/tendermint/tendermint/my_project/data_provenance/web/dao"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/service"
	"github.com/tendermint/tendermint/proto/tendermint/types"
)

type TxServiceImpl struct {
}

func (txService *TxServiceImpl) DataProvenance(dataType int32, vectorCode string) (*types.ProvDataList, error) {
	return dao.DataProvenance(dataType, vectorCode)
}

func (txService *TxServiceImpl) KnnOperation(tx *types.Tx) ([]byte, error) {
	return dao.KnnOperation(tx)
}

func (txService *TxServiceImpl) SubmitTx() error {
	return dao.Submit()
}

var _ service.TxService = (*TxServiceImpl)(nil)
