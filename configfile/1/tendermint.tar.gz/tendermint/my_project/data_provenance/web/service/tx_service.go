package service

import (
	"github.com/tendermint/tendermint/proto/tendermint/types"
)

type TxService interface {
	DataProvenance(int32, string) (*types.ProvDataList, error)
	KnnOperation(tx *types.Tx) ([]byte, error)
	SubmitTx() error
}
