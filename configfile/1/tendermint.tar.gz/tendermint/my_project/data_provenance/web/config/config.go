package config

const (
	TendermintRPCAddr = "http://localhost:26657"
	CliNum            = 1000
	RedisPassword     = "123456"
)
