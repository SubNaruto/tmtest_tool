package controller

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/gogo/protobuf/proto"
	"github.com/tendermint/tendermint/abci/example/kvstore/go-hnsw"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/service"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/service/impl"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/util"
	"github.com/tendermint/tendermint/proto/tendermint/types"
	"io"
	"os"
	"strconv"
	"time"
)

func DataProvenanceHandler(context *gin.Context) {
	// 匿名结构体，用于解析json数据
	var paramBody struct {
		VectorCode string `json:"vector_code"`
		DataType   int32  `json:"data_type"`
	}

	// 将json数据解析到结构体上
	if err := context.BindJSON(&paramBody); err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  err.Error(),
		})
		return
	}

	//vectorCode := context.PostForm("vector_code")
	//dataType, err := strconv.ParseUint(context.PostForm("data_type"), 10, 64)
	//if err != nil {
	//	context.JSON(200, gin.H{
	//		"code": 1,
	//		"msg":  err.Error(),
	//	})
	//	return
	//}

	var txService service.TxService = new(impl.TxServiceImpl)
	provDataList, err := txService.DataProvenance(paramBody.DataType, paramBody.VectorCode)
	// provDataList, err := txService.DataProvenance(int32(dataType), vectorCode)
	if err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  err.Error(),
		})
		return
	}

	txArr, vos, err := util.VerifyProvDataList(provDataList)
	if err != nil {
		return
	}

	//for i := 0; i < len(txBodyArr); i++ {
	//	fmt.Println(txBodyArr[i].OpType, txBodyArr[i].Version, txBodyArr[i].DataType)
	//}

	context.JSON(200, gin.H{
		"code": 0,
		"msg":  "verification success",
		"data": txArr,
		"vo":   vos,
	})
}

func KnnOperationHandler(context *gin.Context) {
	// 匿名结构体，用于解析json数据
	var paramBody struct {
		VectorCode string     `json:"vector_code"` // 特征向量ID
		OpType     uint32     `json:"op_type"`     // 操作类型
		Vector     hnsw.Point `json:"vector"`      // 特征向量
		K          int        `json:"k"`           // 查询参数k
		DataType   int32      `json:"data_type"`   // 数据类型
	}

	// 将Json数据解析到结构体上
	if err := context.BindJSON(&paramBody); err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  err.Error(),
		})
		return
	}

	key0 := util.GenTxKey(paramBody.DataType, paramBody.VectorCode) // 根据data_type和vector_code构造向量的key
	cmd := util.Redis.Incr(key0)                                    // 根据key从redis读取版本号,并+1
	if cmd.Err() != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  cmd.Err().Error(),
		})
		return
	}

	version := cmd.Val() // 获得版本号

	txBody := &types.TxBody{
		VectorCode: paramBody.VectorCode,
		OpType:     types.OperationType(paramBody.OpType),
		Vector:     paramBody.Vector,
		K:          int64(paramBody.K),
		Timestamp:  time.Now().Format("2006-01-02 15:04:05"),
		Version:    uint32(version),
		DataType:   types.DataType(paramBody.DataType),
	}

	tx := &types.Tx{
		TxBody: txBody,
		Key:    util.GenTxKeyWithVersion(key0, txBody.Version),
	}

	var txService service.TxService = &impl.TxServiceImpl{}

	data, err := txService.KnnOperation(tx)

	if err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  "txService.KnnOperation(tx) " + err.Error(),
		})
		return
	}

	if tx.TxBody.OpType != types.OperationType_SELECT {
		context.JSON(200, gin.H{
			"code": 0,
			"msg":  "knn operation success",
		})
		return
	}

	var knnResponse types.KnnResponse
	err = proto.Unmarshal(data, &knnResponse)
	if err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  "proto.Unmarshal(data, &knnResponse) " + err.Error(),
		})
		return
	}

	context.JSON(200, gin.H{
		"code": 0,
		"msg":  knnResponse.Kresults,
	})
}

func KnnOperationHandler0(context *gin.Context) {
	// 匿名结构体，用于解析json数据
	var paramBody struct {
		VectorCode string      `json:"vector_code"` // 特征向量ID
		OpType     uint32      `json:"op_type"`     // 操作类型
		Vector     interface{} `json:"vector"`      // 特征向量
		K          int         `json:"k"`           // 查询参数k
		DataType   int32       `json:"data_type"`   // 数据类型
	}

	// 将Json数据解析到结构体上
	if err := context.BindJSON(&paramBody); err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  err.Error(),
		})
		return
	}

	key0 := util.GenTxKey(paramBody.DataType, paramBody.VectorCode) // 根据data_type和vector_code构造向量的key
	cmd := util.Redis.Incr(key0)                                    // 根据key从redis读取版本号,并+1
	if cmd.Err() != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  cmd.Err().Error(),
		})
		return
	}

	var vector hnsw.Point
	temp := paramBody.Vector.([]interface{})
	for i := 0; i < len(temp); i++ {
		float, err := strconv.ParseFloat(temp[i].(string), 10)
		if err != nil {
			context.JSON(200, gin.H{
				"code": 1,
				"msg":  err.Error(),
			})
			return
		}
		vector = append(vector, float32(float))
	}

	version := cmd.Val() // 获得版本号

	txBody := &types.TxBody{
		VectorCode: paramBody.VectorCode,
		OpType:     types.OperationType(paramBody.OpType),
		Vector:     vector,
		K:          int64(paramBody.K),
		Timestamp:  time.Now().Format("2006-01-02 15:04:05"),
		Version:    uint32(version),
		DataType:   types.DataType(paramBody.DataType),
	}

	tx := &types.Tx{
		TxBody: txBody,
		Key:    util.GenTxKeyWithVersion(key0, txBody.Version),
	}

	var txService service.TxService = &impl.TxServiceImpl{}

	data, err := txService.KnnOperation(tx)

	if err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  "txService.KnnOperation(tx) " + err.Error(),
		})
		return
	}

	if tx.TxBody.OpType != types.OperationType_SELECT {
		context.JSON(200, gin.H{
			"code": 0,
			"msg":  "knn operation success",
		})
		return
	}

	var knnResponse types.KnnResponse
	err = proto.Unmarshal(data, &knnResponse)
	if err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  "proto.Unmarshal(data, &knnResponse) " + err.Error(),
		})
		return
	}

	context.JSON(200, gin.H{
		"code": 0,
		"msg":  knnResponse.Kresults,
	})
}

func SubmitTxController(context *gin.Context) {
	var txService service.TxService = new(impl.TxServiceImpl)
	err := txService.SubmitTx()
	if err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  err.Error(),
		})
		return
	}

	filename := os.Getenv("HOME") + "/abci.log"
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	var size int64
	var c int
	for range ticker.C {
		stat, err := os.Stat(filename)
		if err != nil {
			context.JSON(200, gin.H{
				"code": 1,
				"msg":  err.Error(),
			})
			return
		}

		if size == 0 {
			size = stat.Size()
		} else {
			if size == stat.Size() {
				c++
			} else {
				c = 0
				size = stat.Size()
			}
		}

		if c == 3 {
			break
		}
	}

	file, err := os.OpenFile(filename, os.O_RDONLY, 0777)
	if err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  err.Error(),
		})
		return
	}

	data, err := io.ReadAll(file)
	if err != nil {
		context.JSON(200, gin.H{
			"code": 1,
			"msg":  err.Error(),
		})
		return
	}

	s := string(data)

	fmt.Println(s)

	context.JSON(200, gin.H{
		"code": 0,
		"data": s,
	})
}
