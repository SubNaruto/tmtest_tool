package util

import (
	"github.com/tendermint/tendermint/my_project/data_provenance/web/config"
	"github.com/tendermint/tendermint/rpc/client/http"
	netHttp "net/http"
)

var (
	CliList []*http.HTTP
	Idx     uint32
)

func InitCliList() error {
	CliList = make([]*http.HTTP, config.CliNum)
	for i := 0; i < len(CliList); i++ {
		cli, err := http.NewWithClient(config.TendermintRPCAddr, "/websocket", &netHttp.Client{})
		if err != nil {
			return err
		}
		CliList[i] = cli
	}
	Idx = 0
	return nil
}
