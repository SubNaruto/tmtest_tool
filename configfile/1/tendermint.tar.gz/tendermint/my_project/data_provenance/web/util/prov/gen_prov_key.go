package prov

import (
	"fmt"
	"github.com/tendermint/tendermint/proto/tendermint/types"
)

func GenerateProvKey(dataType types.DataType, vectorCode string) string {
	return fmt.Sprintf("%d@%s", dataType, vectorCode)
}
