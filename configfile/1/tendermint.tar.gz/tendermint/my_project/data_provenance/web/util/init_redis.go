package util

import (
	"github.com/go-redis/redis"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/config"
)

var Redis *redis.Client

func InitRedis() error {
	Redis = redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: config.RedisPassword,
	})
	_, err := Redis.Ping().Result()
	if err != nil {
		return err
	}
	return nil
}
