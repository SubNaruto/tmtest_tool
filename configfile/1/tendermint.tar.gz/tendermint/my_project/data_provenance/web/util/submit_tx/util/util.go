package util

import (
	"context"
	"github.com/go-redis/redis"
	"github.com/gogo/protobuf/proto"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/util"
	"github.com/tendermint/tendermint/proto/tendermint/types"
	"github.com/tendermint/tendermint/rpc/client/http"
	"math/rand"
	"strconv"
	"time"
)

func GenerateInsertTx(r *redis.Client, vectorCode int, value []float32, datatype types.DataType, userId string) *types.Tx {
	vectorCodeStr := strconv.Itoa(vectorCode)

	key := util.GenTxKey(int32(datatype), vectorCodeStr)

	cmd := r.Incr(key)
	if cmd.Err() != nil {
		panic(cmd.Err())
	}

	txBody := &types.TxBody{
		VectorCode: vectorCodeStr,
		OpType:     types.OperationType_INSERT,
		Vector:     value,
		DataType:   datatype,
		Version:    uint32(cmd.Val()),
		K:          0,
		Timestamp:  time.Now().Format("2006-01-02 15:04:05"),
		UserId:     userId,
	}

	return &types.Tx{
		Key:    util.GenTxKeyWithVersion(key, txBody.Version),
		TxBody: txBody,
	}
}

func GenerateQueryTx(value []float32, k int64, datatype types.DataType) *types.Tx {
	txBody := &types.TxBody{
		VectorCode: "",
		OpType:     types.OperationType_SELECT,
		Vector:     value,
		DataType:   datatype,
		K:          k,
		Timestamp:  time.Now().Format("2006-01-02 15:04:05"),
		Version:    0,
	}

	txKey := util.GenTxKeyWithVersion(util.GenTxKey(int32(txBody.DataType), txBody.VectorCode), txBody.Version)

	return &types.Tx{
		Key:    txKey,
		TxBody: txBody,
	}
}

func GenerateUpdateTx(r *redis.Client, vectorCode int, value []float32, datatype types.DataType, userId string) *types.Tx {
	vectorCodeStr := strconv.Itoa(vectorCode)

	key := util.GenTxKey(int32(datatype), vectorCodeStr)

	cmd := r.Incr(key)
	if cmd.Err() != nil {
		panic(cmd.Err())
	}

	txBody := &types.TxBody{
		VectorCode: vectorCodeStr,
		OpType:     types.OperationType_UPDATE,
		Vector:     value,
		DataType:   datatype,
		Version:    uint32(cmd.Val()),
		K:          0,
		Timestamp:  time.Now().Format("2006-01-02 15:04:05"),
		UserId:     userId,
	}

	return &types.Tx{
		Key:    util.GenTxKeyWithVersion(key, txBody.Version),
		TxBody: txBody,
	}
}

func SendTx(cli *http.HTTP, tx *types.Tx) error {
	pbTx, err := proto.Marshal(tx)
	if err != nil {
		panic(err)
	}

	_, err = cli.BroadcastTxAsync(context.TODO(), pbTx)
	return err
}

func RandomPoint() []float32 {
	v := make([]float32, 128)
	for i := range v {
		v[i] = rand.Float32() * 10
	}
	return v
}
