package util

import (
	"github.com/tendermint/tendermint/rpc/client/http"
	"sync/atomic"
)

func NewTendermintCli() *http.HTTP {
	idx := atomic.LoadUint32(&Idx)
	if !atomic.CompareAndSwapUint32(&Idx, uint32(len(CliList)-1), 0) {
		atomic.AddUint32(&Idx, 1)
	}
	return CliList[idx]
}
