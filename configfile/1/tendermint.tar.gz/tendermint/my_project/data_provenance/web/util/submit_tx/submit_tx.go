package main

import (
	"context"
	"fmt"
	"github.com/go-redis/redis"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/config"
	"log"
	"math/rand"
	netHttp "net/http"
	"strconv"
	"time"

	"github.com/gogo/protobuf/proto"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/util"
	"github.com/tendermint/tendermint/proto/tendermint/types"
	"github.com/tendermint/tendermint/rpc/client/http"
)

var r *redis.Client

func init() {
	r = redis.NewClient(&redis.Options{
		Addr:     "localhost:6379",
		Password: config.RedisPassword,
	})
	_, err := r.Ping().Result()
	if err != nil {
		panic(err)
	}
}

func generateInsertTx(vectorCode int, value []float32, datatype types.DataType, userId string) *types.Tx {
	vectorCodeStr := strconv.Itoa(vectorCode)

	key := util.GenTxKey(int32(datatype), vectorCodeStr)

	cmd := r.Incr(key)
	if cmd.Err() != nil {
		panic(cmd.Err())
	}

	txBody := &types.TxBody{
		VectorCode: vectorCodeStr,
		OpType:     types.OperationType_INSERT,
		Vector:     value,
		DataType:   datatype,
		Version:    uint32(cmd.Val()),
		K:          0,
		Timestamp:  time.Now().Format("2006-01-02 15:04:05"),
		UserId:     userId,
	}

	return &types.Tx{
		Key:    util.GenTxKeyWithVersion(key, txBody.Version),
		TxBody: txBody,
	}
}

func generateQueryTx(value []float32, k int64, datatype types.DataType) *types.Tx {
	txBody := &types.TxBody{
		VectorCode: "",
		OpType:     types.OperationType_SELECT,
		Vector:     value,
		DataType:   datatype,
		K:          k,
		Timestamp:  time.Now().Format("2006-01-02 15:04:05"),
		Version:    0,
	}

	txKey := util.GenTxKeyWithVersion(util.GenTxKey(int32(txBody.DataType), txBody.VectorCode), txBody.Version)

	return &types.Tx{
		Key:    txKey,
		TxBody: txBody,
	}
}

func generateUpdateTx(vectorCode int, value []float32, datatype types.DataType, userId string) *types.Tx {
	vectorCodeStr := strconv.Itoa(vectorCode)

	key := util.GenTxKey(int32(datatype), vectorCodeStr)

	cmd := r.Incr(key)
	if cmd.Err() != nil {
		panic(cmd.Err())
	}

	txBody := &types.TxBody{
		VectorCode: vectorCodeStr,
		OpType:     types.OperationType_UPDATE,
		Vector:     value,
		DataType:   datatype,
		Version:    uint32(cmd.Val()),
		K:          0,
		Timestamp:  time.Now().Format("2006-01-02 15:04:05"),
		UserId:     userId,
	}

	return &types.Tx{
		Key:    util.GenTxKeyWithVersion(key, txBody.Version),
		TxBody: txBody,
	}
}

func sendTx(cli *http.HTTP, tx *types.Tx) {
	pbTx, err := proto.Marshal(tx)
	if err != nil {
		panic(err)
	}

	_, err = cli.BroadcastTxAsync(context.TODO(), pbTx)
	if err != nil {
		log.Fatal(err)
	}
}

func randomPoint() []float32 {
	v := make([]float32, 128)
	for i := range v {
		v[i] = rand.Float32() * 10
	}
	return v
}

func main() {
	// 与本地Tendermint节点建立连接
	cli, err := http.NewWithClient("http://localhost:26657", "/websocket", &netHttp.Client{})
	if err != nil {
		panic(err)
	}

	// 插入数据
	for vectorCode := 0; vectorCode < 100; vectorCode++ { // vectorCode从0到99, 总计100个
		fmt.Printf("send insert tx %d\n", vectorCode)
		v := randomPoint()
		tx1 := generateInsertTx(vectorCode+1, v, types.DataType_VIDEO, "001")  // 插入视频类型的数据(100个)
		tx2 := generateInsertTx(vectorCode+1, v, types.DataType_SERIES, "001") // 插入序列类型的数据(100个)
		tx3 := generateInsertTx(vectorCode+1, v, types.DataType_TEXT, "001")   // 插入文本类型的数据(100个)

		sendTx(cli, tx1)
		sendTx(cli, tx2)
		sendTx(cli, tx3)
	}

	// 更新数据
	for i := 0; i < 3; i++ { // 更新3次
		fmt.Printf("send update tx on vector %d\n", 1)
		v := randomPoint()

		tx1 := generateUpdateTx(10, v, types.DataType_VIDEO, "001") // vectorCode=10 且 类型为视频 的数据
		sendTx(cli, tx1)

		tx2 := generateUpdateTx(10, v, types.DataType_SERIES, "001") // vectorCode=10 且 类型为序列 的数据
		sendTx(cli, tx2)

		tx3 := generateUpdateTx(10, v, types.DataType_TEXT, "001") // vectorCode=10 且 类型为文本 的数据
		sendTx(cli, tx3)
	}
}
