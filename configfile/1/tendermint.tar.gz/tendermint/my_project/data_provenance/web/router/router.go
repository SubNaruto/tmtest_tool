package router

import (
	"github.com/gin-gonic/gin"
	"github.com/tendermint/tendermint/my_project/data_provenance/web/controller"
	"os/exec"
)

func GenRouter() *gin.Engine {
	engine := gin.Default()

	engine.POST("/dataProvenance", controller.DataProvenanceHandler)

	engine.POST("/knnOperation", controller.KnnOperationHandler) // for apiPost

	engine.POST("/knnOperation0", controller.KnnOperationHandler0) // for vue

	engine.POST("/submitTx", controller.SubmitTxController)

	engine.POST("/jmeter", func(context *gin.Context) { // just for test
		command := "/test.sh"
		cmd := exec.Command("/bin/bash", "-c", command)
		output, err := cmd.Output()
		if err != nil {
			context.JSON(200, gin.H{
				"code": 1,
				"msg":  err.Error(),
			})
			return
		}
		context.JSON(200, gin.H{
			"code": 0,
			"msg":  string(output),
		})
	})

	return engine
}
