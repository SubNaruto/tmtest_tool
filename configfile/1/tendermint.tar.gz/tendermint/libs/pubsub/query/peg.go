package query

//go:generate peg -inline -switch query.peg
