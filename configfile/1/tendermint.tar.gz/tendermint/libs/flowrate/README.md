Data Flow Rate Control
======================

To download and install this package run:

go get github.com/mxk/go-flowrate/flowrate

The documentation is available at:

<http://godoc.org/github.com/mxk/go-flowrate/flowrate>
