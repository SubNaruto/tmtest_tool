# Local Cluster with Docker Compose

See the [docs](https://docs.tendermint.com/v0.34/networks/docker-compose.html).
