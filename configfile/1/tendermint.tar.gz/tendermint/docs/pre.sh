#!/bin/bash

cp -a ../rpc/openapi/ .vuepress/public/rpc/
