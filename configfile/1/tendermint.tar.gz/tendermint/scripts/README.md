* http://redsymbol.net/articles/unofficial-bash-strict-mode/
