package core

import (
	tmproto "github.com/tendermint/tendermint/proto/tendermint/types"
	ctypes "github.com/tendermint/tendermint/rpc/core/types"
	rpctypes "github.com/tendermint/tendermint/rpc/jsonrpc/types"
)

func ProvQuery(ctx *rpctypes.Context, dataType int32, vectorCode string) (*ctypes.ResultProv, error) {
	r, err := env.BlockStore.LoadProvData(tmproto.DataType(dataType), vectorCode)
	if err != nil {
		return nil, err
	}

	return &ctypes.ResultProv{ProvDataList: r}, nil
}
