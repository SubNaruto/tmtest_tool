package db

import tmdb "github.com/tendermint/tm-db"

type DB interface {
	tmdb.DB

	// GetBlockParts 输入height和total，获取所有分片
	GetBlockParts(int, int) ([][]byte, error)

	// SetBlockPart 输入key和part，保存一个区块分片数据
	SetBlockPart([]byte, []byte)

	// GetBlockPart 输入height和index，获取一个区块分片数据
	GetBlockPart(int, int) ([]byte, error)

	// SetProvData 存储溯源数据
	SetProvData([]byte, []byte)

	// GetProvData 根据entityId获取所有溯源数据
	GetProvData(string) ([][]byte, error)
}
